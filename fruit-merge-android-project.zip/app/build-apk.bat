@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-apk.ps1" %*
pause
