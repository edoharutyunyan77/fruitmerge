@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-aab.ps1" %*
pause
