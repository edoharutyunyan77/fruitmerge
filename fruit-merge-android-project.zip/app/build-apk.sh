#!/usr/bin/env bash
# Builds an APK you can install directly on your phone for TESTING (no signing key needed):   bash build-apk.sh
set -e
cd "$(dirname "$0")"
VC="${1:-1}"; VN="${2:-1.0}"
say() { printf "\n\033[1m== %s ==\033[0m\n" "$*"; }
need() { command -v "$1" >/dev/null 2>&1 || { echo "MISSING: $1 -> $2"; exit 1; }; }

# Android Studio ships a JDK; use it if java is not installed
if ! command -v java >/dev/null 2>&1; then
  for j in "/Applications/Android Studio.app/Contents/jbr/Contents/Home" "$HOME/android-studio/jbr" "/opt/android-studio/jbr"; do
    [ -x "$j/bin/java" ] && export JAVA_HOME="$j" && export PATH="$j/bin:$PATH" && break
  done
fi
need node "install Node.js 20+ from https://nodejs.org"
need npm "install Node.js 20+ from https://nodejs.org"
need java "install Android Studio (it includes a JDK) or JDK 17+"
need keytool "install Android Studio or JDK 17+"
need jarsigner "install Android Studio or JDK 17+"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then for d in "$HOME/Library/Android/sdk" "$HOME/Android/Sdk"; do [ -d "$d" ] && SDK="$d" && break; done; fi
[ -d "$SDK" ] || { echo "Android SDK not found. Install Android Studio and open it once (it downloads the SDK), then run this again."; exit 1; }

CUR=$(node -p "require('./capacitor.config.json').appId")
if [ "$CUR" = "com.yourname.fruitmergedeluxe" ]; then
  echo "Choose your own unique app id, e.g. com.yourname.fruitmerge (lowercase letters, digits, dots). It can never be changed after publishing."
  read -rp "App id: " NEW
  echo "$NEW" | grep -Eq '^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$' || { echo "Invalid app id."; exit 1; }
  node -e "const f='capacitor.config.json',c=require('./'+f);c.appId=process.argv[1];require('fs').writeFileSync(f,JSON.stringify(c,null,2)+'\n')" "$NEW"
fi

if grep -q '"testing": true' scripts/fm-config.json; then
  echo; echo "NOTE: scripts/fm-config.json still uses Google TEST ads. Fine for a test build; for the real release put your AdMob ids there and set testing to false, then run this script again."
  read -rp "Continue? [y/N] " A; [ "$A" = "y" ] || [ "$A" = "Y" ] || exit 0
fi

say "1/4 Installing packages";   npm install
say "2/4 Building the game";     npm run build:www
say "3/4 Android project"
[ -d android ] || npx cap add android
npm run patch
npm run assets || echo "(icon generation skipped)"
npm run sync
printf 'sdk.dir=%s\n' "$SDK" > android/local.properties
node -e "const fs=require('fs'),f='android/app/build.gradle';let s=fs.readFileSync(f,'utf8');s=s.replace(/versionCode\s*=?\s*\d+/,'versionCode '+process.argv[1]).replace(/versionName\s*=?\s*\"[^\"]*\"/,'versionName \"'+process.argv[2]+'\"');fs.writeFileSync(f,s)" "$VC" "$VN"

say "4/4 Building the test APK (first time takes several minutes)"
( cd android && chmod +x gradlew && ./gradlew assembleDebug )
APK="android/app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || { echo "Build failed: $APK not found."; exit 1; }
cp "$APK" fruit-merge-test.apk
echo; echo "DONE: $(pwd)/fruit-merge-test.apk"
echo "Send it to your phone (USB, Telegram, Drive...), open it and allow 'Install unknown apps' when asked."
