# One-command build for Windows. Double-click build-aab.bat (or run: powershell -ExecutionPolicy Bypass -File build-aab.ps1 [versionCode] [versionName])
param([string]$VC = "1", [string]$VN = "1.0")
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
function Say($m) { Write-Host "`n== $m ==" -ForegroundColor Cyan }
function Run { param([string]$cmd) & cmd.exe /c $cmd; if ($LASTEXITCODE -ne 0) { throw "Failed: $cmd" } }
function Need($c, $hint) { if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { throw "MISSING: $c -> $hint" } }

# Android Studio ships a JDK; use it if java is not installed
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
  foreach ($j in @("C:\Program Files\Android\Android Studio\jbr", "$env:LOCALAPPDATA\Programs\Android Studio\jbr")) {
    if (Test-Path "$j\bin\java.exe") { $env:JAVA_HOME = $j; $env:Path = "$j\bin;$env:Path"; break }
  }
}
Need node "install Node.js 20+ from https://nodejs.org"
Need npm "install Node.js 20+ from https://nodejs.org"
Need java "install Android Studio (it includes a JDK) or JDK 17+"
Need keytool "install Android Studio or JDK 17+"
Need jarsigner "install Android Studio or JDK 17+"

$sdk = $env:ANDROID_HOME; if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk) { $sdk = "$env:LOCALAPPDATA\Android\Sdk" }
if (-not (Test-Path $sdk)) { throw "Android SDK not found. Install Android Studio and open it once (it downloads the SDK), then run this again." }

$cfg = Get-Content capacitor.config.json -Raw | ConvertFrom-Json
if ($cfg.appId -eq "com.yourname.fruitmergedeluxe") {
  Write-Host "Choose your own unique app id, e.g. com.yourname.fruitmerge (lowercase letters, digits, dots). It can never be changed after publishing."
  $new = Read-Host "App id"
  if ($new -notmatch '^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$') { throw "Invalid app id." }
  $cfg.appId = $new
  ($cfg | ConvertTo-Json -Depth 5) | Set-Content capacitor.config.json -Encoding UTF8
}

if ((Get-Content scripts\fm-config.json -Raw) -match '"testing":\s*true') {
  Write-Host "`nNOTE: scripts\fm-config.json still uses Google TEST ads. Fine for a test build; for the real release put your AdMob ids there and set testing to false, then run this again." -ForegroundColor Yellow
  if ((Read-Host "Continue? [y/N]") -ne "y") { exit }
}

Say "1/6 Installing packages"; Run "npm install"
Say "2/6 Building the game";   Run "npm run build:www"
Say "3/6 Android project"
if (-not (Test-Path android)) { Run "npx cap add android" }
Run "npm run patch"
try { Run "npm run assets" } catch { Write-Host "(icon generation skipped)" }
Run "npm run sync"
"sdk.dir=" + ($sdk -replace '\\', '\\') | Set-Content android\local.properties -Encoding ASCII
$g = Get-Content android\app\build.gradle -Raw
$g = $g -replace 'versionCode\s*=?\s*\d+', "versionCode $VC" -replace 'versionName\s*=?\s*"[^"]*"', "versionName `"$VN`""
Set-Content android\app\build.gradle $g -Encoding UTF8

Say "4/6 Building the release bundle (first time takes several minutes)"
Push-Location android; Run "gradlew.bat bundleRelease"; Pop-Location
$aab = "android\app\build\outputs\bundle\release\app-release.aab"
if (-not (Test-Path $aab)) { throw "Build failed: $aab not found." }

Say "5/6 Signing key"
$ks = Join-Path $env:USERPROFILE "fruit-merge-upload-key.jks"
if (-not (Test-Path $ks)) {
  Write-Host "Creating your upload key: $ks"
  Write-Host "Choose a password and WRITE IT DOWN. BACK UP the .jks file and the password. If you lose them you can never update the app." -ForegroundColor Yellow
  & keytool -genkeypair -v -keystore $ks -alias upload -keyalg RSA -keysize 2048 -validity 10000
  if ($LASTEXITCODE -ne 0) { throw "keytool failed" }
}

Say "6/6 Signing the bundle"
$out = "fruit-merge-release-v$VC.aab"; Copy-Item $aab $out -Force
& jarsigner -keystore $ks -sigalg SHA256withRSA -digestalg SHA-256 $out upload
if ($LASTEXITCODE -ne 0) { throw "jarsigner failed" }
Write-Host "`nDONE: $PWD\$out  <- upload this file in Play Console" -ForegroundColor Green
Write-Host "Your key: $ks  (back it up!)"
