#!/usr/bin/env bash
# One-command build for macOS / Linux:   bash build-aab.sh            (optional: bash build-aab.sh 2 1.1  = versionCode versionName)
set -e
cd "$(dirname "$0")"
VC="${1:-1}"; VN="${2:-1.0}"
say() { printf "\n\033[1m== %s ==\033[0m\n" "$*"; }
need() { command -v "$1" >/dev/null 2>&1 || { echo "MISSING: $1 -> $2"; exit 1; }; }

# Android Studio ships a JDK; use it if java is not installed
if ! command -v java >/dev/null 2>&1; then
  for j in "/Applications/Android Studio.app/Contents/jbr/Contents/Home" "$HOME/android-studio/jbr" "/opt/android-studio/jbr"; do
    [ -x "$j/bin/java" ] && export JAVA_HOME="$j" && export PATH="$j/bin:$PATH" && break
  done
fi
need node "install Node.js 20+ from https://nodejs.org"
need npm "install Node.js 20+ from https://nodejs.org"
need java "install Android Studio (it includes a JDK) or JDK 17+"
need keytool "install Android Studio or JDK 17+"
need jarsigner "install Android Studio or JDK 17+"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then for d in "$HOME/Library/Android/sdk" "$HOME/Android/Sdk"; do [ -d "$d" ] && SDK="$d" && break; done; fi
[ -d "$SDK" ] || { echo "Android SDK not found. Install Android Studio and open it once (it downloads the SDK), then run this again."; exit 1; }

CUR=$(node -p "require('./capacitor.config.json').appId")
if [ "$CUR" = "com.yourname.fruitmergedeluxe" ]; then
  echo "Choose your own unique app id, e.g. com.yourname.fruitmerge (lowercase letters, digits, dots). It can never be changed after publishing."
  read -rp "App id: " NEW
  echo "$NEW" | grep -Eq '^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$' || { echo "Invalid app id."; exit 1; }
  node -e "const f='capacitor.config.json',c=require('./'+f);c.appId=process.argv[1];require('fs').writeFileSync(f,JSON.stringify(c,null,2)+'\n')" "$NEW"
fi

if grep -q '"testing": true' scripts/fm-config.json; then
  echo; echo "NOTE: scripts/fm-config.json still uses Google TEST ads. Fine for a test build; for the real release put your AdMob ids there and set testing to false, then run this script again."
  read -rp "Continue? [y/N] " A; [ "$A" = "y" ] || [ "$A" = "Y" ] || exit 0
fi

say "1/6 Installing packages";   npm install
say "2/6 Building the game";     npm run build:www
say "3/6 Android project"
[ -d android ] || npx cap add android
npm run patch
npm run assets || echo "(icon generation skipped)"
npm run sync
printf 'sdk.dir=%s\n' "$SDK" > android/local.properties
node -e "const fs=require('fs'),f='android/app/build.gradle';let s=fs.readFileSync(f,'utf8');s=s.replace(/versionCode\s*=?\s*\d+/,'versionCode '+process.argv[1]).replace(/versionName\s*=?\s*\"[^\"]*\"/,'versionName \"'+process.argv[2]+'\"');fs.writeFileSync(f,s)" "$VC" "$VN"

say "4/6 Building the release bundle (first time takes several minutes)"
( cd android && chmod +x gradlew && ./gradlew bundleRelease )
AAB="android/app/build/outputs/bundle/release/app-release.aab"
[ -f "$AAB" ] || { echo "Build failed: $AAB not found."; exit 1; }

say "5/6 Signing key"
KS="$HOME/fruit-merge-upload-key.jks"
if [ ! -f "$KS" ]; then
  echo "Creating your upload key: $KS"
  echo "Choose a password and WRITE IT DOWN. BACK UP the .jks file and the password. If you lose them you can never update the app."
  keytool -genkeypair -v -keystore "$KS" -alias upload -keyalg RSA -keysize 2048 -validity 10000
fi

say "6/6 Signing the bundle"
OUT="fruit-merge-release-v$VC.aab"; cp "$AAB" "$OUT"
jarsigner -keystore "$KS" -sigalg SHA256withRSA -digestalg SHA-256 "$OUT" upload
jarsigner -verify "$OUT" | head -1
echo; echo "DONE: $(pwd)/$OUT  <- upload this file in Play Console"
echo "Your key: $KS  (back it up!)"
