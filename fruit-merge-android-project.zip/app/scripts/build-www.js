// Builds www/index.html from src/game.html:
//  - injects the release settings from scripts/fm-config.json
//  - replaces the Google Fonts links with fonts bundled in the app (works offline)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'fm-config.json'), 'utf8'));
let html = fs.readFileSync(path.join(root, 'src', 'game.html'), 'utf8');

if (!html.includes('<!--FM_CONFIG-->')) throw new Error('Marker <!--FM_CONFIG--> not found in src/game.html');
html = html.replace('<!--FM_CONFIG-->', '<script>window.FM_CONFIG=' + JSON.stringify(cfg) + ';</script>');
html = html.replace(/<link rel="preconnect"[^>]*fonts\.(googleapis|gstatic)\.com[^>]*>\s*/g, '');
html = html.replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com[^>]*>/, '<link rel="stylesheet" href="fonts/fonts.css">');

const www = path.join(root, 'www');
fs.mkdirSync(path.join(www, 'fonts'), { recursive: true });
fs.writeFileSync(path.join(www, 'index.html'), html);

// bundle the fonts from the @fontsource packages (installed by npm install)
const faces = [];
function addFont(pkg, family, weights) {
  const dir = path.join(root, 'node_modules', '@fontsource', pkg, 'files');
  if (!fs.existsSync(dir)) { console.warn('WARN: ' + pkg + ' not installed - run "npm install" first. The game will use fallback fonts.'); return; }
  for (const w of weights) {
    const file = pkg + '-latin-' + w + '-normal.woff2';
    if (!fs.existsSync(path.join(dir, file))) { console.warn('WARN: missing ' + file); continue; }
    fs.copyFileSync(path.join(dir, file), path.join(www, 'fonts', file));
    faces.push("@font-face{font-family:'" + family + "';font-style:normal;font-weight:" + w + ";font-display:swap;src:url('" + file + "') format('woff2');}");
  }
}
addFont('bagel-fat-one', 'Bagel Fat One', [400]);
addFont('nunito', 'Nunito', [700, 800, 900]);
fs.writeFileSync(path.join(www, 'fonts', 'fonts.css'), faces.join('\n') + '\n');
console.log('www/index.html written (' + faces.length + ' font files bundled).');
