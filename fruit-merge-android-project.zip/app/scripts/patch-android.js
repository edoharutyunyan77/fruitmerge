// Run once after "npx cap add android": adds the AdMob app id, the vibration permission and locks the screen to portrait.
const fs = require('fs');
const path = require('path');
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'fm-config.json'), 'utf8'));
const file = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(file)) { console.error('AndroidManifest.xml not found. Run "npx cap add android" first.'); process.exit(1); }
let x = fs.readFileSync(file, 'utf8');
const meta = 'com.google.android.gms.ads.APPLICATION_ID';
if (x.includes(meta)) {
  x = x.replace(new RegExp('(android:name="' + meta.replace(/\./g, '\\.') + '"\\s+android:value=")[^"]*(")'), '$1' + cfg.admob.appId + '$2');
} else {
  x = x.replace('</application>', '    <meta-data android:name="' + meta + '" android:value="' + cfg.admob.appId + '"/>\n    </application>');
}
if (!x.includes('android:screenOrientation')) x = x.replace('android:name=".MainActivity"', 'android:name=".MainActivity"\n            android:screenOrientation="portrait"');
if (!x.includes('android.permission.VIBRATE')) x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
fs.writeFileSync(file, x);
console.log('AndroidManifest.xml patched (AdMob app id + portrait).');

// Full screen (immersive): hides the status bar (clock, battery...) and the navigation buttons so the game fills the whole screen;
// a swipe from the screen edge shows them for a moment. Several methods are combined because phones differ.
(function fullScreen() {
  const javaDir = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'java');
  const find = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const f = path.join(d, e.name); if (e.isDirectory()) { const r = find(f); if (r) return r; } else if (e.name === 'MainActivity.java' || e.name === 'MainActivity.kt') return f; } return null; };
  const file = fs.existsSync(javaDir) ? find(javaDir) : null;
  if (!file) { console.warn('MainActivity not found: full screen skipped.'); return; }
  const pkg = /package\s+([\w.]+)\s*;?/.exec(fs.readFileSync(file, 'utf8'))[1];
  const out = path.join(path.dirname(file), 'MainActivity.java');
  if (file !== out) fs.unlinkSync(file);   // a Kotlin MainActivity is replaced by the Java one below
  fs.writeFileSync(out, `package ${pkg};

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    super.onCreate(savedInstanceState);
    goFullScreen();
    Handler h = new Handler(Looper.getMainLooper());
    h.postDelayed(new Runnable() { public void run() { goFullScreen(); } }, 400);
    h.postDelayed(new Runnable() { public void run() { goFullScreen(); } }, 1500);
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) goFullScreen();
  }

  @SuppressWarnings("deprecation")
  private void goFullScreen() {
    try {
      Window w = getWindow();
      w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
      if (Build.VERSION.SDK_INT >= 28) {
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        w.setAttributes(lp);
      }
      WindowCompat.setDecorFitsSystemWindows(w, false);
      WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
      if (c != null) {
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        c.hide(WindowInsetsCompat.Type.systemBars());
      }
      w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    } catch (Exception e) { /* ignore */ }
  }
}
`);
  console.log('MainActivity.java patched (full screen).');
})();
