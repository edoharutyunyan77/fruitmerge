// Run once after "npx cap add android": adds the AdMob app id, the vibration permission and locks the screen to portrait.
const fs = require('fs');
const path = require('path');
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'fm-config.json'), 'utf8'));
const file = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(file)) { console.error('AndroidManifest.xml not found. Run "npx cap add android" first.'); process.exit(1); }
let x = fs.readFileSync(file, 'utf8');
const meta = 'com.google.android.gms.ads.APPLICATION_ID';
if (x.includes(meta)) {
  x = x.replace(new RegExp('(android:name="' + meta.replace(/\./g, '\\.') + '"\\s+android:value=")[^"]*(")'), '$1' + cfg.admob.appId + '$2');
} else {
  x = x.replace('</application>', '    <meta-data android:name="' + meta + '" android:value="' + cfg.admob.appId + '"/>\n    </application>');
}
if (!x.includes('android:screenOrientation')) x = x.replace('android:name=".MainActivity"', 'android:name=".MainActivity"\n            android:screenOrientation="portrait"');
if (!x.includes('android.permission.VIBRATE')) x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
fs.writeFileSync(file, x);
console.log('AndroidManifest.xml patched (AdMob app id + portrait).');
