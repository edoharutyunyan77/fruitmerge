# Privacy Policy for Fruit Merge Deluxe

*Template, not legal advice. Replace the placeholders in [brackets], then publish this text on a web page and use its link in Play Console.*

Last updated: [date]

Fruit Merge Deluxe ("the app") is provided by [your name or company] ("we"). Contact: [your email].

**Information we collect.** We do not ask you to create an account and we do not collect your name, email or location. Your best score ("record") and Crown Tag count are stored only on your device and are not sent to us.

**Advertising.** The app shows ads using Google AdMob. AdMob and Google may collect and use device information such as the advertising ID, IP address, device and app information and ad interaction data to show and measure ads and to prevent fraud. You can reset or delete your advertising ID or opt out of personalised ads in your device settings (Settings > Google > Ads). Learn how Google uses data: https://policies.google.com/technologies/partner-sites

**Children.** The app is not directed to children under 13 and we do not knowingly collect personal information from children.

**Data sharing and retention.** We do not sell your personal data. Data processed by Google is governed by Google's privacy policy: https://policies.google.com/privacy

**Your choices.** You can uninstall the app at any time, which removes all data stored on your device.

**Changes.** We may update this policy; the date above will change.

**Contact.** [your email]
