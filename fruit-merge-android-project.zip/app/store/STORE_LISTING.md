# Google Play listing (draft)

**App name (max 30):** Fruit Merge Deluxe

**Short description (max 80):**
Merge juicy fruits, drop, match and crown the golden Mango!

**Full description (max 4000):**
Fruit Merge Deluxe is a cozy, addictive puzzle game. Drop the fruits into the crate, match two of the same kind and watch them merge into something bigger.

How it works
- Drag and release to drop a fruit.
- Two matching fruits merge into the next one: Cherry, Strawberry, Mandarin, Apple, Lemon, Peach, Watermelon, Pineapple, Kiwi and the legendary Mango.
- Merge two Mangoes to earn a Crown Tag and set off golden fireworks!
- Don't let the pile cross the line.

Features
- Smooth, satisfying fruit physics
- Cute, expressive fruits
- Crown Tags and personal records saved on your device
- Cheerful music with three styles, and juicy sound effects
- Watch a short optional video ad to remove one fruit and keep your run alive
- Plays offline

Merge, match and wear the crown!

**Category:** Games > Puzzle
**Tags:** puzzle, casual, merge, fruit
**Contact email / website:** (fill in)
**Content rating:** answer the questionnaire honestly (no violence, no user-generated content, contains ads)
**Target audience:** 13+ (do not target children, otherwise Families policy applies)
