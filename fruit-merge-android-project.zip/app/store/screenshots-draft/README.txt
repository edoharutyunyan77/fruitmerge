Draft screenshots (1080x1920) made on a computer. The real game fonts (Bagel Fat One / Nunito) are not
installed there, so the titles use a fallback font. For the Play Store take 4-8 screenshots on your phone
after you install the app (fonts will be correct). Play needs at least 2 phone screenshots.
