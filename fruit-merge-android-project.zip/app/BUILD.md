# Fruit Merge Deluxe: build the Android App Bundle (.aab)

## TEST ON A PHONE FIRST (APK, no signing key)
Same prerequisites as below. Run `bash build-apk.sh` (Mac/Linux) or double-click `build-apk.bat` (Windows). You get `fruit-merge-test.apk`.
Send it to an Android phone, open it and allow "Install unknown apps" for that app when asked. This is only for testing; Play Store needs the .aab from the next section.

## EASY WAY (one command)
1. Install **Node.js 20+** and **Android Studio** (open Android Studio once so it downloads the Android SDK).
2. Unzip this folder.
   - **Windows:** double-click `build-aab.bat`
   - **Mac / Linux:** open Terminal in this folder and run `bash build-aab.sh`
3. Answer the questions (your unique app id, then a password for your signing key). The script installs everything, builds the game, creates the Android project, builds the bundle and signs it.
4. At the end you get `fruit-merge-release-v1.aab` in this folder. Upload it in Play Console.
   For the next update run `bash build-aab.sh 2 1.1` (Windows: `build-aab.bat 2 1.1`) = new versionCode and versionName.

IMPORTANT: the script creates your signing key in your home folder (`fruit-merge-upload-key.jks`). BACK IT UP together with its password. Without them you cannot update the app.
The scripts were written without a real Android machine to test them on. If one step fails, the message says which; the manual steps below do the same thing.
Before the real release put your AdMob ids in `scripts/fm-config.json` and set `"testing": false` (see below), then run the script again.

---

## MANUAL WAY (what the script does)

Everything is prepared. You only need to run the commands below on a computer.

## 0. Install once
- Node.js 20+ (nodejs.org)
- Android Studio (developer.android.com/studio). It installs the Android SDK and a JDK.
- A Google Play developer account (play.google.com/console) and an AdMob account (admob.google.com).

## 1. Pick your own app id
Edit `capacitor.config.json` and change `appId` (e.g. `com.yourname.fruitmerge`). It must be unique and can never be changed after publishing.

## 2. Create the Android project (run in this folder)
```
npm install
npm run build:www          # builds www/index.html + bundles the fonts
npx cap add android
npm run patch              # adds the AdMob app id to the manifest, locks portrait
npm run assets             # generates the app icons + splash screen from /assets
npm run sync
```

## 3. Test on a real phone (with Google's TEST ads)
- Enable Developer options + USB debugging on the phone, connect it, then run `npx cap run android`.
- Check: the game loads, music/sounds work, vibration works (Pause > Vibration), the banner shows "Test Ad", the AD button plays a test video and removes a fruit, the Back button pauses/resumes, and the record is still there after closing the app.

## 4. Switch to your real ads (before the release build only)
Open `scripts/fm-config.json` and replace the three Google TEST ids with yours from AdMob
(app id `ca-app-pub-XXXX~YYYY`, banner unit id, rewarded unit id) and set `"testing": false`. Then:
```
npm run patch
npm run sync
```
Never click your own real ads (AdMob can ban the account). While developing keep `"testing": true`.

## 5. Build the signed .aab
`npx cap open android` -> in Android Studio:
- Set `versionCode` (1, then +1 for every upload) and `versionName` in `android/app/build.gradle`.
- Build > Generate Signed App Bundle / APK > Android App Bundle > create a NEW keystore. **Back it up (file + passwords). If you lose it you cannot update the app.**
- Choose `release`. The file appears in `android/app/release/app-release.aab`.

## 6. Upload in Play Console
Create app > Production (or Internal/Closed testing first) > upload the .aab. Fill in (use the files in `/store`):
- Store listing: texts from `store/STORE_LISTING.md`, icon `store/play-icon-512.png`, feature graphic `store/feature-graphic-1024x500.png`, phone screenshots (take real ones from your phone; the ones in `store/screenshots-draft` are drafts).
- Privacy policy URL: publish `store/PRIVACY_POLICY_TEMPLATE.md` (fill the placeholders) on any web page and paste the link.
- App content: Ads = Yes (contains ads), Data safety form (AdMob collects device/advertising ids, see the template), content rating questionnaire, target audience 13+/18+ (do not select children), Advertising ID declaration = Yes (ads).
- New personal developer accounts may be required to run a closed test with a number of testers for some weeks before production. Check the current rules in Play Console.

## Notes
- The ad / AdMob plugin calls were written from the plugin documentation and tested only against a simulated plugin, not on a real device. Test with the test ids first (step 3). If a method name differs in the plugin version you installed, check the plugin README: https://github.com/capacitor-community/admob
- Edit the game only in `src/game.html`, then run `npm run sync`.
